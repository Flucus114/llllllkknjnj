package com.classselector;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Cópia no cliente dos dados de quests (sem imports só-cliente). */
public class QuestClientState {
    public static final List<QuestTabDef> tabs = new ArrayList<>();
    public static final Map<String, QuestDef> quests = new LinkedHashMap<>();
    public static final Map<String, Integer> progress = new HashMap<>();
    public static final Set<String> done = new HashSet<>();

    public static boolean unlocked(QuestDef q) {
        return q.parent.isEmpty() || !quests.containsKey(q.parent) || done.contains(q.parent);
    }
}
