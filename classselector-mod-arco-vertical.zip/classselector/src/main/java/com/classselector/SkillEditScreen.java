package com.classselector;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.ArrayList;
import java.util.List;

/** Editor de habilidade (só OP): custo de XP, XP recebido, itens recebidos e pré-requisito. */
public class SkillEditScreen extends Screen {
    private final Screen parent;
    private final String treeId;
    private final SkillDef orig;

    private EditBox id, name, desc, icon, cost, reward;
    private Button parentBtn;
    private final List<String> parents = new ArrayList<>();
    private int parentIdx = 0;

    private String classId;
    private Button classBtn;

    private String className(String cid) {
        if (cid.isEmpty()) return "Todas as classes";
        for (ClassDef c : ClientState.classes) if (c.id.equals(cid)) return c.name;
        return cid + " (apagada)";
    }

    private void cycleClass() {
        List<String> opts = new ArrayList<>();
        opts.add("");
        for (ClassDef c : ClientState.classes) opts.add(c.id);
        int i = opts.indexOf(classId);
        classId = opts.get((i + 1) % opts.size());
        classBtn.setMessage(Component.literal("Só a classe: " + className(classId)));
    }

    public SkillEditScreen(Screen parent, String treeId, SkillDef orig) {
        super(Component.literal(orig == null ? "Nova habilidade" : "Editar habilidade"));
        this.parent = parent;
        this.treeId = treeId;
        this.orig = orig;
        this.classId = orig == null ? "" : orig.classId;
        parents.add("");
        for (SkillDef s : SkillClientState.skills.values()) {
            if (s.tree.equals(treeId) && (orig == null || !s.id.equals(orig.id))) parents.add(s.id);
        }
        if (orig != null && parents.contains(orig.parent)) parentIdx = parents.indexOf(orig.parent);
    }

    private EditBox box(int x, int y, int w, int maxLen, String val) {
        EditBox b = new EditBox(font, x, y, w, 18, Component.empty());
        b.setMaxLength(maxLen);
        b.setValue(val);
        addRenderableWidget(b);
        return b;
    }

    private EditBox num(int x, int y, int val) {
        EditBox b = box(x, y, 150, 8, String.valueOf(val));
        b.setFilter(s -> s.isEmpty() || s.matches("\\d*"));
        return b;
    }

    private static int parseInt(EditBox b, int def) {
        try { return Integer.parseInt(b.getValue().trim()); } catch (Exception e) { return def; }
    }

    private int y0() { return Math.max(16, height / 2 - 110); }

    private String parentLabel() {
        String pid = parents.get(parentIdx);
        if (pid.isEmpty()) return "Nenhum (início)";
        SkillDef s = SkillClientState.skills.get(pid);
        return s == null ? pid : s.name;
    }

    @Override
    protected void init() {
        int cx = width / 2, lx = cx - 155, rx = cx + 5, y = y0(), s = 32;

        id = box(lx, y + 11, 150, 64, orig == null ? "" : orig.id);
        id.setEditable(orig == null);
        name = box(lx, y + 11 + s, 150, 64, orig == null ? "" : orig.name);
        desc = box(lx, y + 11 + 2 * s, 150, 256, orig == null ? "" : orig.description);
        icon = box(lx, y + 11 + 3 * s, 150, 256, orig == null ? "minecraft:nether_star" : orig.icon);
        addRenderableWidget(Button.builder(Component.literal("Ícone = item na mão"), b -> {
            ItemStack held = minecraft.player.getMainHandItem();
            if (!held.isEmpty()) icon.setValue(ForgeRegistries.ITEMS.getKey(held.getItem()).toString());
        }).bounds(lx, y + 11 + 4 * s, 150, 20).build());

        cost = num(rx, y + 11, orig == null ? 1 : orig.xpCost);
        reward = num(rx, y + 11 + s, orig == null ? 0 : orig.xpReward);
        parentBtn = addRenderableWidget(Button.builder(Component.literal(parentLabel()), b -> {
            parentIdx = (parentIdx + 1) % parents.size();
            b.setMessage(Component.literal(parentLabel()));
        }).bounds(rx, y + 10 + 2 * s, 150, 20).build());

        classBtn = addRenderableWidget(Button.builder(
                Component.literal("Só a classe: " + className(classId)), b -> cycleClass())
                .bounds(lx, y + 11 + 4 * s + 24, 310, 20).build());

        int by = y + 11 + 4 * s + 50;
        addRenderableWidget(Button.builder(Component.literal("Salvar"), b -> { if (save()) onClose(); })
                .bounds(lx, by, 74, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Itens"), b -> {
            if (save()) Net.CH.sendToServer(new SkillNet.SEditRewards(ClassDef.sanitize(id.getValue())));
        }).bounds(lx + 79, by, 74, 20).build());
        Button del = addRenderableWidget(Button.builder(Component.literal("Excluir"), b -> {
            Net.CH.sendToServer(new SkillNet.SDeleteSkill(orig.id));
            onClose();
        }).bounds(lx + 158, by, 74, 20).build());
        del.active = orig != null;
        addRenderableWidget(Button.builder(Component.literal("Voltar"), b -> onClose())
                .bounds(lx + 237, by, 73, 20).build());
    }

    private boolean save() {
        String sid = ClassDef.sanitize(id.getValue());
        if (sid.isEmpty() || name.getValue().isBlank()) return false;
        SkillDef d = new SkillDef();
        d.id = sid;
        d.tree = treeId;
        d.parent = parents.get(parentIdx);
        d.name = name.getValue().trim();
        d.description = desc.getValue().trim();
        d.icon = icon.getValue().trim();
        d.xpCost = Math.max(0, parseInt(cost, 0));
        d.xpReward = Math.max(0, parseInt(reward, 0));
        d.classId = classId;
        if (orig != null) d.rewards = orig.rewards;
        Net.CH.sendToServer(new SkillNet.SSaveSkill(d.save()));
        return true;
    }

    @Override
    public void onClose() { minecraft.setScreen(parent); }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        int cx = width / 2, lx = cx - 155, rx = cx + 5, y = y0(), s = 32, c = 0xFFAAAAAA;
        g.drawCenteredString(font, title, cx, Math.max(2, y - 12), 0xFFFFFF);
        g.drawString(font, "ID (a-z, 0-9, _)", lx, y, c, false);
        g.drawString(font, "Nome", lx, y + s, c, false);
        g.drawString(font, "Descrição", lx, y + 2 * s, c, false);
        g.drawString(font, "Ícone (id do item)", lx, y + 3 * s, c, false);
        g.drawString(font, "Custo: níveis de XP gastos", rx, y, c, false);
        g.drawString(font, "Recebe: níveis de XP", rx, y + s, c, false);
        g.drawString(font, "Pré-requisito (clique p/ trocar)", rx, y + 2 * s, c, false);
        g.drawString(font, "Os itens recebidos são definidos", rx, y + 3 * s + 6, 0xFF777777, false);
        g.drawString(font, "no botão \"Itens\" (baú).", rx, y + 3 * s + 18, 0xFF777777, false);
        super.render(g, mx, my, pt);
    }
}
