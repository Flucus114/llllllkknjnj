package com.classselector;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Cópia no cliente dos dados da árvore de habilidades. */
public class SkillClientState {
    public static final List<QuestTabDef> trees = new ArrayList<>();
    public static final Map<String, SkillDef> skills = new LinkedHashMap<>();
    public static final Set<String> unlocked = new HashSet<>();

    /** O pré-requisito (se houver) já foi desbloqueado? */
    public static boolean available(SkillDef s) {
        return s.parent.isEmpty() || !skills.containsKey(s.parent) || unlocked.contains(s.parent);
    }
}
