package com.classselector;

import net.minecraft.client.Minecraft;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.Tag;

public class ClientHooks {
    /** open: 0 = só atualiza, 1/2 = tela de classe (opcional/obrigatória), 3/4 = tela de raça (opcional/obrigatória). */
    public static void sync(int open, boolean isOp, String myRace, CompoundTag data) {
        ClientState.classes.clear();
        for (Tag t : data.getList("classes", Tag.TAG_COMPOUND)) ClientState.classes.add(ClassDef.load((CompoundTag) t));
        ClientState.races.clear();
        for (Tag t : data.getList("races", Tag.TAG_COMPOUND)) {
            RaceDef r = RaceDef.load((CompoundTag) t);
            ClientState.races.put(r.id, r);
        }
        ClientState.op = isOp;
        ClientState.myRace = myRace;
        Minecraft mc = Minecraft.getInstance();
        if (open == 1 || open == 2) mc.setScreen(new ClassSelectScreen(open == 2));
        else if (open == 3 || open == 4) mc.setScreen(new RaceSelectScreen(open == 4));
    }

    public static void skillSync(boolean open, CompoundTag data) {
        SkillClientState.trees.clear();
        for (Tag t : data.getList("trees", Tag.TAG_COMPOUND)) SkillClientState.trees.add(QuestTabDef.load((CompoundTag) t));
        SkillClientState.skills.clear();
        for (Tag t : data.getList("skills", Tag.TAG_COMPOUND)) {
            SkillDef s = SkillDef.load((CompoundTag) t);
            SkillClientState.skills.put(s.id, s);
        }
        SkillClientState.unlocked.clear();
        for (Tag t : data.getList("unlocked", Tag.TAG_STRING)) SkillClientState.unlocked.add(t.getAsString());
        if (open) Minecraft.getInstance().setScreen(new SkillScreen());
    }

    public static void questSync(boolean open, CompoundTag data) {
        QuestClientState.tabs.clear();
        for (Tag t : data.getList("tabs", Tag.TAG_COMPOUND)) QuestClientState.tabs.add(QuestTabDef.load((CompoundTag) t));
        QuestClientState.quests.clear();
        for (Tag t : data.getList("quests", Tag.TAG_COMPOUND)) {
            QuestDef q = QuestDef.load((CompoundTag) t);
            QuestClientState.quests.put(q.id, q);
        }
        QuestClientState.progress.clear();
        CompoundTag pr = data.getCompound("progress");
        for (String k : pr.getAllKeys()) QuestClientState.progress.put(k, pr.getInt(k));
        QuestClientState.done.clear();
        for (Tag t : data.getList("done", Tag.TAG_STRING)) QuestClientState.done.add(t.getAsString());
        if (open) Minecraft.getInstance().setScreen(new QuestScreen());
    }
}
