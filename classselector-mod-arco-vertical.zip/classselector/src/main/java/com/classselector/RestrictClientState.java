package com.classselector;

import net.minecraft.world.item.ItemStack;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

/** Regras de bloqueio da classe do jogador local (sem imports só-cliente). */
public class RestrictClientState {
    private static volatile Set<String> rules = new HashSet<>();

    public static void set(Collection<String> r) {
        rules = new HashSet<>(r);
    }

    public static boolean isBlocked(ItemStack s) {
        Set<String> r = rules;
        return !r.isEmpty() && RestrictionData.matches(r, s);
    }
}
