package com.classselector;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.monster.warden.Warden;

/** Lado do cliente: guarda o estado "sentado" na entidade para o modelo usar. */
public class WardenSitClient {
    public static void apply(int entityId, boolean sit) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        Entity e = mc.level.getEntity(entityId);
        if (e instanceof Warden w) w.getPersistentData().putBoolean(TamedWarden.SIT_KEY, sit);
    }
}
